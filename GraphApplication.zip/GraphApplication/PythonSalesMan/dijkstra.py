import graph
import math
import sys
import queue
import operator



# Dijkstra =====================================================================
def Dijkstra(g,start):
    vertices = []
    visitat = []
    
    node = start
    for n in g.Vertices: 
        
        if n != node:
            n.DijkstraDistance = sys.float_info.max
        else:
            n.DijkstraDistance = 0
        vertices.append(n)
    
    while len(vertices) != len(visitat):
        for edge in node.Edges:
            node_desti = edge.Destination
            if node_desti not in visitat:
                distancia = node.DijkstraDistance + edge.Length
                if node_desti.DijkstraDistance > distancia:   
                   node_desti.DijkstraDistance = distancia
                  
        
        visitat.append(node)
        min = 0

        for vertice in vertices:
            if vertice not in visitat:
                if vertice.DijkstraDistance <= min or min == 0:
                    min = vertice.DijkstraDistance
                    node = vertice
    return

    
                
   
                    



# DijkstraQueue ================================================================

def DijkstraQueue(g,start):
    visitat = []
    for n in g.Vertices: 
        #
        n.Anterior = None
        ##
        if n != start:
            n.DijkstraDistance = sys.float_info.max
        else:
            n.DijkstraDistance = 0

    cua = queue.PriorityQueue()
    cua.put((0,start))
    ##
    ###edge_anterior = 0
    ##
    while not cua.empty():
        va = cua.get()
        if va[1] not in visitat:
            for edge in va[1].Edges:
                distancia = edge.Length + edge.Origin.DijkstraDistance
                if edge.Origin == va[1] and edge.Destination.DijkstraDistance > distancia:
                    edge.Destination.DijkstraDistance = distancia
                    cua.put((distancia,edge.Destination))
                    ##  
                    edge.Destination.Anterior = edge                 
                    #edge.anterior = edge_anterior
                    ##edge.Origin.anterior = edge_anterior
                    ###edge_anterior = edge
                    ##
            visitat.append(va[1])
    #
    #edge.Origin.anterior = None
    #
    return 