import graph
import subprocess
import sys
import time
import dijkstra
import greedy
import backtracking
import branchAndBound

# ==============================================================================
# IDENTIFICACIO DELS ALUMNES ===================================================
# ==============================================================================

graph.NomAlumne1 = "Alba"
graph.CognomsAlumne1 = "Ballarà Sala"
graph.NIUAlumne1 = "1597532"

# No modificar si nomes grup d'un alumne

graph.NomAlumne2 = "Blanca"
graph.CognomsAlumne2 = "de Juan Cavaller"
graph.NIUAlumne2 = "1604365"

# VERIFICAR ALUMNES =============================================================

graph.TestNIU(graph.NIUAlumne1)
if graph.NIUAlumne2!="": graph.TestNIU(graph.NIUAlumne2)


# EXECUCIO EN PROCESS DE CORRECCIO ==============================================

if graph.CorrectionProcess(): sys.exit(0)

# ==============================================================================
# PROVES =======================================================================
# ==============================================================================

g=graph.Graph()                                            # crear un graf
g.Load("TestSalesMan/Graf100_200_17.GR")                     # llegir el graf
g.SetDistancesToEdgeLength()                               # Posar les longituts de les arestes a la distancia entre vertexs
vis=graph.Visits(g);                                       # Crear les visistes
vis.Load("TestSalesMan/RepeatVertex.VIS")                  # llegir les visistes
t0 = time.time()                                           # temps inicial
trk=branchAndBound.SalesmanTrackBranchAndBound2(g,vis)          #Cerca cami que pasi per les visites
t1 = time.time()                                           # Temps final
print("temps: ",t1-t0)                                     # imprimir el temps d'execució
trk.Display(vis)   