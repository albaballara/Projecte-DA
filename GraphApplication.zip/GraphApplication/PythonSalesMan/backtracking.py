import graph
import math
import sys
import queue
import dijkstra

global longitud
global millor_cami

millor_cami = []
longitud = 1.7976931348623157e+308


def solucio(v,d, visits, cami, vertices_cami, pes_actual):
    global millor_cami, longitud
    #comprova si es una possible solució
    if v != d:
        return False

    for visit in visits.Vertices:
        if visit not in vertices_cami:
            return False

    if longitud > pes_actual:
        longitud = pes_actual
        millor_cami = []
        for c in cami:
            millor_cami.append(c)
    return True


def RecSalesmanTrackBacktracking(g,visits, vertices_cami, cami, v, d, pes_actual):
    global longitud, millor_cami
    if (pes_actual) > longitud: return
    if solucio(v,d, visits, cami, vertices_cami, pes_actual):
        if len(v.Edges) < 2:
            return
   
    for edge in v.Edges:
        if edge.Visited == False:
                cami.append(edge)
                pes_actual +=  edge.Length
                vertices_cami.append(edge.Destination)
                edge.Visited = True
                RecSalesmanTrackBacktracking(g,visits, vertices_cami, cami, edge.Destination, d, pes_actual)
       
                edge.Visited = False
                vertices_cami.pop()
                cami.pop()
                pes_actual -=  edge.Length
 
                #######################################################3              
    return 
                

def SalesmanTrackBacktracking(g,visits):
    global longitud, millor_cami
    v = visits.Vertices[0]
    d = visits.Vertices[-1]
    vertices_cami = [v]
    cami = []
    
    #pes_max = sys.float_info.max
    pes_actual = 0
    RecSalesmanTrackBacktracking(g,visits, vertices_cami, cami, v, d, pes_actual)
    track = graph.Track(g)

    track.Edges = millor_cami
    
    return track

