import graph
import queue
import dijkstra


# SalesmanTrackGreedy ==========================================================

def inicialitza(g):
    for vertex in g.Vertices:
        vertex.DijkstraDistance = 1.7976931348623157e+308
        vertex.Visited = False

def SalesmanTrackGreedy(g,visits):
    visits = visits.Vertices
    v = visits[0]
    candidats = visits[1:-1]
    millor_cami = []
    
    while candidats != []:
        inicialitza(g)
        anteriors={v:v}
        actual = v
        v.DijkstraDistance=0
    
        while actual is not None:
            actual.Visited = True
        
            for v2 in actual.Edges:
                n2=v2.Destination
                if not n2.Visited:
                    if (actual.DijkstraDistance + v2.Length < n2.DijkstraDistance):
                        anteriors[n2]=v2
                        n2.DijkstraDistance = actual.DijkstraDistance + v2.Length
            
            minim = 1.7976931348623157e+308
            seg_v = None
            for vertex in g.Vertices:
                if not vertex.Visited:
                    if vertex.DijkstraDistance < minim:
                        minim, seg_v = vertex.DijkstraDistance, vertex
            actual = seg_v
        
        minim = 1.7976931348623157e+308
        seg_v =None
        for vertex in candidats:
            if vertex.DijkstraDistance < minim:
                minim, seg_v = vertex.DijkstraDistance, vertex
                
        v1 = seg_v

        candidats.remove(v1)
        aux = v1
        cami =[]
        while anteriors[v1] is not v: 
            edge=anteriors[v1]
            cami.insert(0,edge)
            v1 = edge.Origin
        millor_cami.extend(cami)
        v = aux
 
    inicialitza(g)
    anteriors = {v:v}
    actual = v
    v.DijkstraDistance=0
    
    while actual is not None:
        actual.Visited = True
        
        for v2 in actual.Edges:
            n2 = v2.Destination
            if not n2.Visited:
                if (actual.DijkstraDistance + v2.Length < n2.DijkstraDistance):
                    anteriors[n2]=v2
                    n2.DijkstraDistance = actual.DijkstraDistance + v2.Length

        minim = 1.7976931348623157e+308
        seg_v = None
        for vertex in g.Vertices:
            if not vertex.Visited:
                if vertex.DijkstraDistance < minim:
                    minim, seg_v = vertex.DijkstraDistance, vertex
                   
        actual = seg_v

    v1 = visits[-1]
    cami=[]
    while anteriors[v1] is not v:
            edge=anteriors[v1]
            cami.insert(0,edge)
            v1=edge.Origin
    millor_cami.extend(cami)
    
    track = graph.Track(g) 
    track.Edges = millor_cami   
 
    return track
    

