import graph
import math
import queue
import dijkstra


global maxims
global minims
global sup
global inf

sup = 0
inf = 0
maxims = []
minims = []

# SalesmanTrackBranchAndBound1 ===================================================

def SalesmanTrackBranchAndBound1(g, visits):
    return graph.Track(g)


# SalesmanTrackBranchAndBound2 ===================================================

def inicialitzation(g,visits):
    global maxims, minims, sup, inf
    m = []
    
    #CREA UNA FILA PER CADA NODE DE VISITS
    for node in visits.Vertices:
        fila=[]
        dijkstra.DijkstraQueue(g, node)
        for x in visits.Vertices: 
            distance = x.DijkstraDistance
            fila.append(distance)
        #afegim cada fila a la matriu
        m.append(fila)

        max_fila = 0 
        min_fila = 1.7976931348623157e+308 
        fila = fila[:-1]
        trobat = False
        for c in range(len(fila)):
            if 0 < fila[c] < min_fila:
                min_fila = fila[c]
                trobat = True
        if not trobat:
            min_fila = 0
            
        #aqui guarda la suma dels valors maxims i minims de cada fila 
        maxims.append(max_fila)
        minims.append(min_fila)

    sup = sum(maxims)
    inf = sum(minims)
    #cotes del camí buit:
    #suma del min de cada col (inf)
    #suma del maxim de cada col (sup)
    return m 



def recalcular(nou_max,minim_max,pos = 0):   
    if pos == 1:
        if nou_max < minim_max + 1.7976931348623157e+308: 
            return True
        return False
    if nou_max < minim_max + 1.7976931348623157e+308: 
        return nou_max
    return minim_max


def crear_track(g,visits,cami):
    track = graph.Track(g) #crea track
    for pos_node in range(len(cami[:-1])):
        dijkstra.DijkstraQueue(g, visits.Vertices[cami[pos_node]])
        previous = visits.Vertices[cami[pos_node+1]]
        
        edge_previous = previous.Anterior
        auxiliar = graph.Track(g)
        while edge_previous != None:
            auxiliar.AddFirst(edge_previous)
            edge_previous = edge_previous.Origin.Anterior
            
        track.Append(auxiliar)
    return track


def es_solucio(indexs_visites, cami):
    for index in indexs_visites: 
        if index not in cami:
            return False
    return True


def SalesmanTrackBranchAndBound2(g, visits):
    global maxims, minims, sup, inf
    minim_max = sup
    m = inicialitzation(g,visits)
    m.pop()
    cua = queue.PriorityQueue()
    index_visites = [i for i, j in enumerate(visits.Vertices)]

    cua.put((inf, sup, [0]))
    while not cua.empty():
        inf, sup, cami = cua.get()
        if recalcular(inf,minim_max,1):
            if es_solucio(index_visites, cami):
                return crear_track(g,visits,cami) #funcio que ens retorna el track
            else:
                for fila in range(len(m)): 
                    if fila not in cami:
                        fila_min = minims[fila] 
                        fila_max = maxims[fila]
                        matriu = m[cami[-1]][fila]
                        nou_min = inf-fila_min + matriu
                        nou_max = sup-fila_max + matriu
                        minim_max = recalcular(nou_max,minim_max)
                        nou_cami = cami+[fila]
                        if len(nou_cami) == len(m): #quan tenen la mateixa longitud
                            ultim_min=  minims[-1]
                            ultim_max = maxims[-1]
                            matriu = m[nou_cami[-1]][-1]
                            
                            nou_min = nou_min- ultim_min+matriu
                            nou_max = nou_max+ ultim_max+matriu

                            minim_max = recalcular(nou_max,minim_max)
                            nou_cami.append(index_visites[-1])
                        cua.put((nou_min, nou_max, nou_cami))

    cami.append(index_visites[-1])
    return crear_track(g,visits,cami) 


# SalesmanTrackBranchAndBound3 ===================================================

def SalesmanTrackBranchAndBound3(g, visits):
    return graph.Track(g)