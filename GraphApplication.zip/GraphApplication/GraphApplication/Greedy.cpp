#include "pch.h"
#include "Graph.h"


// SalesmanTrackGreedy =========================================================

CTrack SalesmanTrackGreedy(CGraph& graph, CVisits &visits)
{
	return CTrack(&graph);
}
